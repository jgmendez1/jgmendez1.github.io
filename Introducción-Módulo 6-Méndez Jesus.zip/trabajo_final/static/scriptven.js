const pixton = document.getElementById("pixton");

pixton.addEventListener("click", function() {
abrirNuevaVentana("https://www.pixton.com/es/");
});
function abrirNuevaVentana(url) {
window.open(url, "_blank");
}